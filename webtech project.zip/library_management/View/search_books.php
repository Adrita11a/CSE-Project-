<?php 
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if ($_SESSION["user"]["role"] !== "member") { header("Location: dashboard.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Search Books</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f4f4f9;
    margin: 0;
    padding: 20px;
}
.container {
    max-width: 800px;
    margin: auto;
}
h2 {
    color: #007BFF;
    margin-bottom: 15px;
}
#keyword {
    padding: 6px 10px;
    width: 100%;
    max-width: 300px;
    margin-bottom: 15px;
    border-radius: 5px;
    border: 1px solid #ccc;
}
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 5px;
}
th, td {
    padding: 8px 10px;
    border-bottom: 1px solid #ccc;
    text-align: left;
}
th {
    background: #007BFF;
    color: #fff;
    font-weight: normal;
}
tr:hover {
    background: #e6f0ff;
}
button {
    padding: 5px 10px;
    background: #28a745;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
}
button:disabled {
    background: #aaa;
    cursor: not-allowed;
}
.links a {
    display: inline-block;
    margin-top: 15px;
    text-decoration: none;
    padding: 6px 12px;
    background: #007BFF;
    color: #fff;
    border-radius: 5px;
    font-size: 14px;
}
.links a:hover {
    background: #0056b3;
}
</style>
</head>
<body>
<div class="container">
    <h2>Search Books</h2>
    <input type="text" id="keyword" placeholder="Search book..." oninput="loadBooks()">

    <div id="tableWrap"></div>

    <div class="links">
        <a href="dashboard.php">Back</a>
    </div>
</div>

<script>
function loadBooks(){
    const k = document.getElementById("keyword").value.trim();
    fetch("../Controller/SearchController.php?keyword=" + encodeURIComponent(k))
    .then(r => r.json())
    .then(d => render(d.books || []));
}

function render(books){
    let html = `<table>
        <tr><th>Title</th><th>Author</th><th>Available</th><th>Action</th></tr>`;
    
    if(books.length === 0){
        html += `<tr><td colspan="4" style="text-align:center;">No books found</td></tr>`;
    } else {
        books.forEach(b => {
            const btn = b.available_copies > 0
                ? `<button onclick="request(${b.id}, this)">Request</button>`
                : `<button disabled>Not available</button>`;
            html += `<tr>
                <td>${b.title}</td>
                <td>${b.author}</td>
                <td>${b.available_copies}</td>
                <td>${btn}</td>
            </tr>`;
        });
    }

    html += `</table>`;
    document.getElementById("tableWrap").innerHTML = html;
}

function request(bookId, btn){
    const fd = new FormData();
    fd.append("book_id", bookId);

    fetch("../Controller/RequestController.php?action=send", {
        method: "POST",
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        alert(d.msg || (d.ok ? "Request sent" : "Request failed"));
        if(d.ok) {
            btn.disabled = true;
            btn.textContent = "Pending";
        }
    })
    .catch(()=> alert("Request failed"));
}

loadBooks();
</script>
</body>
</html>
