<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
$role = $_SESSION["user"]["role"] ?? "";
if (!in_array($role, ["admin","librarian"], true)) { header("Location: dashboard.php"); exit; }

require_once __DIR__ . "/../Model/Issue.php";
$rows = issue_getApprovedNotIssued();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Issue Book</title>
  <link rel="stylesheet" href="style.css">
  <style>
    table{width:100%;border-collapse:collapse;margin-top:10px;}
    th,td{padding:8px;border-bottom:1px solid #334155;font-size:14px;}
    button{width:auto;padding:6px 10px;}
    .note{font-size:12px;color:#94a3b8;margin-top:6px;}
  </style>
</head>
<body>
<div class="container" style="max-width:1100px;">
  <h2>Issue Book (Approved Requests)</h2>
  <div class="note">Only approved requests are shown here. Click Issue to create an Issue record and reduce available copies.</div>

  <div id="msgBox" class="msg" style="display:none;"></div>

  <table>
    <tr>
      <th>Request ID</th>
      <th>Member</th>
      <th>Email</th>
      <th>Book</th>
      <th>Available</th>
      <th>Action</th>
    </tr>

    <?php if (empty($rows)): ?>
      <tr><td colspan="6">No approved requests to issue.</td></tr>
    <?php else: foreach ($rows as $r): ?>
      <tr>
        <td><?php echo (int)$r["request_id"]; ?></td>
        <td><?php echo htmlspecialchars($r["member_name"]); ?></td>
        <td><?php echo htmlspecialchars($r["member_email"]); ?></td>
        <td><?php echo htmlspecialchars($r["book_title"]); ?></td>
        <td><?php echo (int)$r["available_copies"]; ?></td>
        <td>
          <?php if ((int)$r["available_copies"] > 0): ?>
            <button onclick="issueNow(<?php echo (int)$r['request_id']; ?>)">Issue</button>
          <?php else: ?>
            Not available
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; endif; ?>
  </table>

  <?php
require_once __DIR__ . "/../Model/Issue.php";
$returnRows = issue_getIssuedListForReturn("");
?>
<hr style="border:1px solid #334155;margin:18px 0;">

<h2 style="margin-top:0;">Return Book</h2>
<div class="note">Search issued books and click Return. Fine will be calculated automatically.</div>

<input type="text" id="returnKeyword" placeholder="Search member name/email/book" oninput="loadReturnList()">

<div id="returnWrap" style="margin-top:10px;"></div>

<script>
function loadReturnList(){
  const k = document.getElementById("returnKeyword").value.trim();

  // simple approach: reload page section using fetch JSON endpoint (we create quick endpoint below)
  fetch("../Controller/ReturnListController.php?keyword=" + encodeURIComponent(k))
    .then(r=>r.json())
    .then(d=>{
      if(!d.ok) return;
      renderReturn(d.rows || []);
    });
}

function renderReturn(rows){
  let html = `<table>
    <tr>
      <th>Issue ID</th><th>Member</th><th>Email</th><th>Book</th><th>Due Date</th><th>Action</th>
    </tr>`;

  if(rows.length===0){
    html += `<tr><td colspan="6">No issued books found</td></tr>`;
  } else {
    rows.forEach(r=>{
      html += `<tr>
        <td>${r.issue_id}</td>
        <td>${r.member_name}</td>
        <td>${r.member_email}</td>
        <td>${r.book_title}</td>
        <td>${r.due_date}</td>
        <td><button onclick="returnNow(${r.issue_id})">Return</button></td>
      </tr>`;
    });
  }

  html += `</table>`;
  document.getElementById("returnWrap").innerHTML = html;
}

function returnNow(issueId){
  if(!confirm("Return this book?")) return;

  const fd = new FormData();
  fd.append("issue_id", issueId);

  fetch("../Controller/IssueController.php?action=return",{
    method:"POST",
    body:fd
  })
  .then(r=>r.json())
  .then(d=>{
    if(d.ok){
      if(d.fine > 0){
        showMsg("success", d.msg + " | Late days: " + d.late_days + " | Fine: " + d.fine);
      } else {
        showMsg("success", d.msg + " | No fine");
      }
      setTimeout(()=>location.reload(), 700);
    } else {
      showMsg("error", d.msg || "Return failed");
    }
  });
}

// initial load
loadReturnList();
</script>


  <div class="links" style="margin-top:10px;">
    <a href="dashboard.php">Back</a>
  </div>
</div>

<script>
function showMsg(type, text){
  const box = document.getElementById("msgBox");
  box.style.display = "block";
  box.className = "msg " + (type === "success" ? "success" : "error");
  box.innerText = text;
}

function issueNow(requestId){
  if(!confirm("Issue this book now?")) return;

  const fd = new FormData();
  fd.append("request_id", requestId);

  fetch("../Controller/IssueController.php?action=issue", {
    method: "POST",
    body: fd
  })
  .then(r => r.json())
  .then(d => {
    if(d.ok){
      showMsg("success", d.msg + " | Due: " + (d.due_date || ""));
      setTimeout(() => location.reload(), 600);
    } else {
      showMsg("error", d.msg || "Issue failed");
    }
  })
  .catch(() => showMsg("error", "Network error"));
}
</script>
</body>
</html>
