<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Forgot Password</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h2>Forgot Password</h2>
    <p>We will do this page next.</p>
    <div class="links">
      <a href="login.php">Back to login</a>
    </div>
  </div>
</body>
</html>
