<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if (($_SESSION["user"]["role"] ?? "") !== "member") { header("Location: dashboard.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Issued Book History</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f4f4f9;
    margin: 0;
    padding: 15px;
}
.container {
    max-width: 750px;
    margin: auto;
}
h2 {
    color: #007BFF;
    margin-bottom: 15px;
    font-size: 1.2em;
}
/* Table */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 6px;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
th, td {
    padding: 6px 8px;
    font-size: 13px;
    border-bottom: 1px solid #ccc;
}
th {
    background: #007BFF;
    color: #fff;
    text-align: left;
}
tr:hover {
    background: #e6f0ff;
}
/* Status badges */
.tag {
    display: inline-block;
    padding: 2px 6px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
}
.issued { background: rgba(59,130,246,.15); border:1px solid rgba(59,130,246,.35); color:#1d4ed8; }
.returned { background: rgba(34,197,94,.15); border:1px solid rgba(34,197,94,.35); color:#166534; }
/* Back link */
.links a {
    text-decoration: none;
    background: #007BFF;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
    padding: 8px 12px;
    display: inline-block;
}
.links a:hover { background: #0056b3; }
#message { margin-top:10px; font-size: 13px; color:#555; text-align:center; }
</style>
</head>
<body>
<div class="container">
<h2>My Issued Book History</h2>

<table id="issuedTable">
    <tr>
        <th>Book</th>
        <th>Issue Date</th>
        <th>Due Date</th>
        <th>Return Date</th>
        <th>Status</th>
    </tr>
</table>

<div id="message">Loading...</div>

<div class="links">
    <a href="dashboard.php">Back</a>
</div>
</div>

<script>
var xhr = new XMLHttpRequest();
xhr.open('GET', '../Controller/IssueController.php?action=member_issued', true);

xhr.onload = function() {
    const table = document.getElementById('issuedTable');
    const message = document.getElementById('message');
    
    if (xhr.status === 200) {
        try {
            var data = JSON.parse(xhr.responseText);
            
            if(!data || data.length===0){
                message.textContent = "No issued books found.";
                return;
            }
            message.textContent = "";
            data.forEach(function(r){
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><b>${r.title}</b><br><small>${r.author || ''}</small></td>
                    <td>${r.issue_date}</td>
                    <td>${r.due_date}</td>
                    <td>${r.return_date || '-'}</td>
                    <td><span class="tag ${r.status}">${r.status}</span></td>
                `;
                table.appendChild(tr);
            });
        } catch(err) {
            message.textContent = "Failed to load data.";
            console.error(err);
        }
    } else {
        message.textContent = "Failed to load data.";
        console.error('HTTP Error: ' + xhr.status);
    }
};

xhr.onerror = function() {
    document.getElementById('message').textContent = "Failed to load data.";
    console.error('Request failed');
};

xhr.send();
</script>
</body>
</html>
