<?php
session_start();
if (isset($_SESSION["user"])) {
    header("Location: dashboard.php");
    exit;
}

$err = $_SESSION["flash_error"] ?? "";
unset($_SESSION["flash_error"]);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Register - Library Management System</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background-color: #ffffff;
      font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif;
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .header {
      background-color: #0066cc;
      color: white;
      padding: 20px 0;
      text-align: center;
      box-shadow: 0 2px 8px rgba(0, 102, 204, 0.15);
    }

    .header h1 {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 5px;
    }

    .header p {
      font-size: 14px;
      opacity: 0.9;
    }

    .register-wrapper {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      padding: 40px 20px;
    }

    .container {
      max-width: 500px;
      width: 100%;
      padding: 45px;
      background-color: #ffffff;
      border-radius: 10px;
      box-shadow: 0 8px 32px rgba(0, 102, 204, 0.25);
      border-top: 6px solid #0066cc;
    }

    h2 {
      color: #0066cc;
      margin-bottom: 25px;
      text-align: center;
      font-size: 24px;
      font-weight: 600;
    }

    .msg {
      padding: 12px 15px;
      border-radius: 5px;
      margin-bottom: 15px;
      font-weight: 500;
      font-size: 14px;
    }

    .msg.error {
      background-color: #ffe6e6;
      color: #cc0000;
      border-left: 4px solid #cc0000;
    }

    .msg.success {
      background-color: #e6f9ff;
      color: #0066cc;
      border-left: 4px solid #0066cc;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .input-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    label {
      font-weight: 600;
      color: #0066cc;
      font-size: 14px;
    }

    input[type="text"],
    input[type="password"],
    input[type="email"] {
      padding: 12px 14px;
      border: 1px solid #d0d0d0;
      border-radius: 5px;
      font-size: 14px;
      font-family: Arial, sans-serif;
      transition: all 0.3s;
      background-color: #fafafa;
    }

    input[type="text"]:focus,
    input[type="password"]:focus,
    input[type="email"]:focus {
      outline: none;
      border-color: #0066cc;
      background-color: #ffffff;
      box-shadow: 0 0 5px rgba(0, 102, 204, 0.2);
    }

    .small-note {
      font-size: 12px;
      margin-top: 3px;
      font-weight: 500;
    }

    button[type="submit"] {
      padding: 12px 20px;
      background-color: #0066cc;
      color: white;
      border: none;
      border-radius: 5px;
      font-weight: 600;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s;
      margin-top: 10px;
    }

    button[type="submit"]:hover {
      background-color: #004fa3;
    }

    .links {
      margin-top: 25px;
      text-align: center;
      border-top: 1px solid #e0e0e0;
      padding-top: 20px;
    }

    .links a {
      color: #0066cc;
      text-decoration: none;
      font-size: 14px;
      transition: color 0.3s;
    }

    .links a:hover {
      color: #004fa3;
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>Library Management System</h1>
    <p>Create Your Account</p>
  </div>

  <div class="register-wrapper">
    <div class="container">
      <h2>Register</h2>

      <?php if ($err): ?>
        <div class="msg error"><?php echo htmlspecialchars($err); ?></div>
      <?php endif; ?>

      <form method="post" action="../Controller/AuthController.php" onsubmit="return validateRegister()">
        <input type="hidden" name="form_type" value="register">

        <div class="input-group">
          <label>Full Name</label>
          <input type="text" name="full_name" id="full_name" placeholder="Your name">
        </div>

        <div class="input-group">
          <label>Email</label>
          <input type="text" name="email" id="email" placeholder="example@mail.com" onblur="checkEmailAjax()">
          <div class="small-note" id="email_note"></div>
        </div>

        <div class="input-group">
          <label>Phone (optional)</label>
          <input type="text" name="phone" id="phone" placeholder="01XXXXXXXXX">
        </div>

        <div class="input-group">
          <label>Password</label>
          <input type="password" name="password" id="password" placeholder="min 6 characters">
        </div>

        <div class="input-group">
          <label>Confirm Password</label>
          <input type="password" name="confirm_password" id="confirm_password" placeholder="repeat password">
        </div>

        <div id="reg_js_error" class="msg error" style="display:none;"></div>

        <button type="submit">Create Account</button>
      </form>

      <div class="links">
        <a href="login.php">Back to login</a>
      </div>
    </div>
  </div>

<script>
let emailExists = false;

function showRegError(msg) {
  const box = document.getElementById("reg_js_error");
  box.style.display = "block";
  box.innerText = msg;
}

function validateRegister() {
  const name = document.getElementById("full_name").value.trim();
  const email = document.getElementById("email").value.trim();
  const pass = document.getElementById("password").value;
  const confirm = document.getElementById("confirm_password").value;

  const box = document.getElementById("reg_js_error");
  box.style.display = "none";
  box.innerText = "";

  if (name.length < 3) return showRegError("Name must be at least 3 characters."), false;
  if (email === "") return showRegError("Email is required."), false;
  if (!email.includes("@") || !email.includes(".")) return showRegError("Enter a valid email."), false;
  if (pass.length < 6) return showRegError("Password must be at least 6 characters."), false;
  if (pass !== confirm) return showRegError("Passwords do not match."), false;

  if (emailExists) return showRegError("This email already exists. Please login."), false;

  return true;
}

function checkEmailAjax() {
  const email = document.getElementById("email").value.trim();
  const note = document.getElementById("email_note");
  note.innerText = "";
  emailExists = false;

  if (email === "" || !email.includes("@")) return;

  fetch("../Controller/AuthController.php?action=check_email&email=" + encodeURIComponent(email))
    .then(res => res.json())
    .then(data => {
      if (data.exists) {
        emailExists = true;
        note.innerText = "Email already exists.";
        note.style.color = "#fca5a5";
      } else {
        emailExists = false;
        note.innerText = "Email available.";
        note.style.color = "#86efac";
      }
    })
    .catch(() => {
      note.innerText = "Could not check email.";
      note.style.color = "#fca5a5";
    });
}
</script>
</body>
</html>
