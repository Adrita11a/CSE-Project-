<?php
session_start();
if(!isset($_SESSION["user"])){header("Location: login.php");exit;}
require_once __DIR__."/../Model/User.php";
$user=user_findById((int)$_SESSION["user"]["id"]);
if(!$user){header("Location: ../Controller/AuthController.php?action=logout");exit;}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Profile</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f4f9;margin:0;padding:15px}
.container{max-width:500px;margin:auto;background:#fff;padding:15px;border-radius:8px;box-shadow:0 1px 6px rgba(0,0,0,0.1)}
h2{color:#007BFF;margin-bottom:15px;font-size:1.2em}
.input-group{margin-bottom:10px}
.input-group label{display:block;font-size:13px;margin-bottom:2px}
.input-group input{width:100%;padding:6px;border:1px solid #ccc;border-radius:5px}
button{padding:7px 12px;background:#007BFF;color:#fff;border:none;border-radius:5px;cursor:pointer}
button:hover{background:#0056b3}
.msg{padding:5px 8px;border-radius:5px;font-size:12px;margin-bottom:8px}
.msg.error{background:#f8d7da;color:#842029}
.msg.success{background:#d1e7dd;color:#0f5132}
.links a {
    font-size: 16px;      
    text-decoration: none;
    margin-right: 10px;   
    color: #007BFF;
    font-weight: bold;
}
.links a:hover {
    color: #0056b3;
}

.small-note{font-size:12px;color:#555;margin-bottom:10px}
</style>
</head>
<body>
<div class="container">
<h2>My Profile</h2>
<div id="msg_box"></div>
<div class="input-group"><label>Full Name</label><input type="text" id="full_name" value="<?=htmlspecialchars($user["full_name"])?>"></div>
<div class="input-group"><label>Email (cannot change)</label><input type="text" value="<?=htmlspecialchars($user["email"])?>" disabled></div>
<div class="input-group"><label>Phone (optional)</label><input type="text" id="phone" value="<?=htmlspecialchars($user["phone"]??"")?>"></div>
<div class="small-note">Role: <b><?=htmlspecialchars($user["role"])?></b></div>
<button onclick="updateProfile()">Update Profile</button>
<div class="links"><a href="change_password.php">Change Password</a>|<a href="dashboard.php">Dashboard</a>|<a href="../Controller/AuthController.php?action=logout">Logout</a></div>
</div>

<script>
function updateProfile(){
 let name=document.getElementById("full_name").value.trim();
 let phone=document.getElementById("phone").value.trim();
 let box=document.getElementById("msg_box");
 box.innerText="";
 box.className="";
 if(name.length<3)
{box.innerText="Name ≥3 chars";box.className="msg error";return;}
 if(phone!="" && phone.length<8)
    {box.innerText="Phone too short";
   box.className="msg error";return;}
let fd = new FormData();
fd.append("full_name", name);
fd.append("phone", phone);

let xhr = new XMLHttpRequest();
xhr.open("POST", "../Controller/UserController.php?action=update_profile");
xhr.onreadystatechange = function () {
  if (xhr.readyState === 4) {
    try {
      const d = JSON.parse(xhr.responseText || "{}");
      box.innerText = d.msg || (d.ok ? "Success" : "Failed");
      box.className = d.ok ? "msg success" : "msg error";
    } catch (e) {
      box.innerText = "Failed to parse response";
      box.className = "msg error";
    }
  }
};
xhr.onerror = function () {
  box.innerText = "Failed";
  box.className = "msg error";
};
xhr.send(fd);
}
</script>
</body>
</html>
