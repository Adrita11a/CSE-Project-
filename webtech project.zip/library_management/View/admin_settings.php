<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if (($_SESSION["user"]["role"] ?? "") !== "admin") { header("Location: dashboard.php"); exit; }

require_once __DIR__ . "/../Model/Settings.php";
$settings = settings_getAll();

$err = $_SESSION["flash_error"] ?? "";
$ok  = $_SESSION["flash_success"] ?? "";
unset($_SESSION["flash_error"], $_SESSION["flash_success"]);

$maxDays = $settings["max_borrow_days"] ?? "7";
$finePerDay = $settings["fine_per_day"] ?? "5";
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Settings</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h2>System Settings</h2>

  <?php if ($err): ?><div class="msg error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="msg success"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>

  <form method="post" action="../Controller/SettingsController.php" onsubmit="return validateSettings()">

    <div class="input-group">
      <label>Max Borrow Days</label>
      <input type="text" name="max_borrow_days" id="max_borrow_days" value="<?php echo htmlspecialchars($maxDays); ?>">
    </div>

    <div class="input-group">
      <label>Fine Per Day</label>
      <input type="text" name="fine_per_day" id="fine_per_day" value="<?php echo htmlspecialchars($finePerDay); ?>">
    </div>

    <div id="set_js_error" class="msg error" style="display:none;"></div>

    <button type="submit">Save Settings</button>
  </form>

  <div class="links">
    <a href="dashboard.php">Back</a>
  </div>
</div>

<script>
function validateSettings(){
  const maxDays = document.getElementById("max_borrow_days").value.trim();
  const fine = document.getElementById("fine_per_day").value.trim();
  const box = document.getElementById("set_js_error");
  box.style.display="none"; box.innerText="";

  if (maxDays === "" || isNaN(maxDays) || parseInt(maxDays) <= 0 || parseInt(maxDays) > 60) {
    box.style.display="block";
    box.innerText="Max borrow days must be between 1 and 60.";
    return false;
  }
  if (fine === "" || isNaN(fine) || parseFloat(fine) < 0) {
    box.style.display="block";
    box.innerText="Fine per day must be a valid number (0 or more).";
    return false;
  }
  return true;
}
</script>
</body>
</html>
