<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if (!in_array($_SESSION["user"]["role"], ["librarian","admin"], true)) {
  header("Location: dashboard.php"); exit;
}
require_once __DIR__ . "/../Model/BorrowRequest.php";
$rows = borrowRequest_getAllPending();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Borrow Requests</title>
  <link rel="stylesheet" href="style.css">
  <style>
    table{width:100%;border-collapse:collapse}
    th,td{padding:8px;border-bottom:1px solid #334155}
  </style>
</head>
<body>
<div class="container" style="max-width:900px;">
<h2>Borrow Requests</h2>

<table>
<tr><th>Member</th><th>Book</th><th>Date</th><th>Action</th></tr>
<?php if(empty($rows)): ?>
<tr><td colspan="4">No pending requests</td></tr>
<?php else: foreach($rows as $r): ?>
<tr>
<td><?php echo htmlspecialchars($r["member_name"]); ?></td>
<td><?php echo htmlspecialchars($r["book_title"]); ?></td>
<td><?php echo $r["request_date"]; ?></td>
<td>
  <button onclick="act(<?php echo $r['id']; ?>,'approved')">Approve</button>
  <button onclick="act(<?php echo $r['id']; ?>,'rejected')">Reject</button>
</td>
</tr>
<?php endforeach; endif; ?>
</table>

<div class="links">
<a href="dashboard.php">Back</a>
</div>
</div>

<script>
function act(id,status){
  const fd = new FormData();
  fd.append("id",id);
  fd.append("status",status);

  fetch("../Controller/RequestController.php?action=update",{
    method:"POST",
    body:fd
  })
  .then(r=>r.json())
  .then(d=>{
    if(d.ok) location.reload();
    else alert("Action failed");
  });
}
</script>
</body>
</html>
