<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if (($_SESSION["user"]["role"] ?? "") !== "admin") { header("Location: dashboard.php"); exit; }

$err = $_SESSION["flash_error"] ?? "";
unset($_SESSION["flash_error"]);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add User</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h2>Add User</h2>

    <?php if ($err): ?>
      <div class="msg error"><?php echo htmlspecialchars($err); ?></div>
    <?php endif; ?>

    <form method="post" action="../Controller/AdminController.php?action=add" onsubmit="return validateAddUser()">

      <div class="input-group">
        <label>Full Name</label>
        <input type="text" name="full_name" id="full_name">
      </div>

      <div class="input-group">
        <label>Email</label>
        <input type="text" name="email" id="email">
      </div>

      <div class="input-group">
        <label>Phone (optional)</label>
        <input type="text" name="phone" id="phone">
      </div>

      <div class="input-group">
        <label>Role</label>
        <input type="radio" name="role" value="librarian" id="r1"> <label for="r1">Librarian</label><br>
        <input type="radio" name="role" value="member" id="r2"> <label for="r2">Member</label>
      </div>

      <div class="input-group">
        <label>Password</label>
        <input type="password" name="password" id="password">
      </div>

      <div class="input-group">
        <label>Confirm Password</label>
        <input type="password" name="confirm_password" id="confirm_password">
      </div>

      <div id="add_js_error" class="msg error" style="display:none;"></div>

      <button type="submit">Create User</button>
    </form>

    <div class="links">
      <a href="admin_users.php">Back to Users</a> |
      <a href="dashboard.php">Dashboard</a>
    </div>
  </div>

<script>
function validateAddUser() {
  const name = document.getElementById("full_name").value.trim();
  const email = document.getElementById("email").value.trim();
  const pass = document.getElementById("password").value;
  const confirm = document.getElementById("confirm_password").value;
  const role1 = document.getElementById("r1").checked;
  const role2 = document.getElementById("r2").checked;

  const box = document.getElementById("add_js_error");
  box.style.display = "none";
  box.innerText = "";

  if (name.length < 3) { box.style.display="block"; box.innerText="Name must be at least 3 characters."; return false; }
  if (email === "" || !email.includes("@") || !email.includes(".")) { box.style.display="block"; box.innerText="Enter a valid email."; return false; }
  if (!role1 && !role2) { box.style.display="block"; box.innerText="Please select a role."; return false; }
  if (pass.length < 6) { box.style.display="block"; box.innerText="Password must be at least 6 characters."; return false; }
  if (pass !== confirm) { box.style.display="block"; box.innerText="Passwords do not match."; return false; }

  return true;
}
</script>
</body>
</html>
