<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if (($_SESSION["user"]["role"] ?? "") !== "admin") { header("Location: dashboard.php"); exit; }

require_once __DIR__ . "/../Model/Report.php";

$counts = report_dashboardCounts();
$latest = report_latestIssues(10);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Reports</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:10px;}
    .card{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:12px;}
    .card h3{margin:0;font-size:14px;color:#94a3b8;}
    .card .val{font-size:22px;font-weight:bold;margin-top:6px;}
    table{width:100%;border-collapse:collapse;margin-top:12px;}
    th,td{padding:8px;border-bottom:1px solid #334155;font-size:14px;text-align:left;}
    @media (max-width:900px){ .grid{grid-template-columns:repeat(2,1fr);} }
  </style>
</head>
<body>
<div class="container" style="max-width:1100px;">
  <h2>Reports & Analytics</h2>

  <div class="grid">
    <div class="card"><h3>Total Users</h3><div class="val"><?php echo (int)$counts["total_users"]; ?></div></div>
    <div class="card"><h3>Total Books</h3><div class="val"><?php echo (int)$counts["total_books"]; ?></div></div>
    <div class="card"><h3>Pending Requests</h3><div class="val"><?php echo (int)$counts["pending_requests"]; ?></div></div>
    <div class="card"><h3>Issued Now</h3><div class="val"><?php echo (int)$counts["issued_now"]; ?></div></div>

    <div class="card"><h3>Total Fines</h3><div class="val"><?php echo (int)$counts["total_fines"]; ?></div></div>
    <div class="card"><h3>Unpaid Fines</h3><div class="val"><?php echo (int)$counts["unpaid_fines"]; ?></div></div>
    <div class="card"><h3>Total Fine Amount</h3><div class="val"><?php echo htmlspecialchars($counts["total_fine_amount"]); ?></div></div>
    <div class="card"><h3>Unpaid Amount</h3><div class="val"><?php echo htmlspecialchars($counts["unpaid_fine_amount"]); ?></div></div>
  </div>

  <h3 style="margin-top:18px;">Latest Issue/Return Activity</h3>
  <table>
    <tr>
      <th>Issue ID</th><th>Member</th><th>Book</th><th>Issue Date</th><th>Due</th><th>Status</th>
    </tr>
    <?php if (empty($latest)): ?>
      <tr><td colspan="6">No records yet.</td></tr>
    <?php else: foreach($latest as $r): ?>
      <tr>
        <td><?php echo (int)$r["id"]; ?></td>
        <td><?php echo htmlspecialchars($r["member_name"]); ?></td>
        <td><?php echo htmlspecialchars($r["book_title"]); ?></td>
        <td><?php echo htmlspecialchars($r["issue_date"]); ?></td>
        <td><?php echo htmlspecialchars($r["due_date"]); ?></td>
        <td><?php echo htmlspecialchars($r["status"]); ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </table>

  <div class="links" style="margin-top:10px;">
    <a href="dashboard.php">Back</a>
  </div>
</div>
</body>
</html>
