<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
$role = $_SESSION["user"]["role"] ?? "";
if (!in_array($role, ["admin","librarian"], true)) { header("Location: dashboard.php"); exit; }

require_once __DIR__ . "/../Model/Issue.php";
$rows = issue_getAllCurrentlyIssued();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Issued Books</title>
  <link rel="stylesheet" href="style.css">
  <style>
    table{width:100%;border-collapse:collapse;margin-top:10px;}
    th,td{padding:8px;border-bottom:1px solid #334155;font-size:14px;}
  </style>
</head>
<body>
<div class="container" style="max-width:1100px;">
  <h2>Currently Issued Books</h2>

  <table>
    <tr>
      <th>Issue ID</th>
      <th>Member</th>
      <th>Email</th>
      <th>Book</th>
      <th>Issue Date</th>
      <th>Due Date</th>
    </tr>

    <?php if (empty($rows)): ?>
      <tr><td colspan="6">No issued books right now.</td></tr>
    <?php else: foreach($rows as $r): ?>
      <tr>
        <td><?php echo (int)$r["id"]; ?></td>
        <td><?php echo htmlspecialchars($r["member_name"]); ?></td>
        <td><?php echo htmlspecialchars($r["member_email"]); ?></td>
        <td><?php echo htmlspecialchars($r["book_title"]); ?></td>
        <td><?php echo htmlspecialchars($r["issue_date"]); ?></td>
        <td><?php echo htmlspecialchars($r["due_date"]); ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </table>

  <div class="links" style="margin-top:10px;">
    <a href="dashboard.php">Back</a>
  </div>
</div>
</body>
</html>
