<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
$role = $_SESSION["user"]["role"] ?? "";
if (!in_array($role, ["admin","librarian"], true)) { header("Location: dashboard.php"); exit; }

require_once __DIR__ . "/../Model/Book.php";

$id = (int)($_GET["id"] ?? 0);
$book = ($id > 0) ? book_findById($id) : null;

if (!$book) { header("Location: librarian_books.php"); exit; }

$err = $_SESSION["flash_error"] ?? "";
unset($_SESSION["flash_error"]);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Book</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background-color: #ffffff;
      font-family: Arial, sans-serif;
      color: #333;
    }

    .container {
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      background-color: #f8f9ff;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 102, 204, 0.1);
    }

    h2 {
      color: #0066cc;
      margin-bottom: 20px;
      border-bottom: 3px solid #0066cc;
      padding-bottom: 10px;
    }

    .msg {
      padding: 12px 15px;
      border-radius: 5px;
      margin-bottom: 15px;
      font-weight: 500;
    }

    .msg.error {
      background-color: #ffe6e6;
      color: #cc0000;
      border-left: 4px solid #cc0000;
      display: none;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .input-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    label {
      font-weight: 600;
      color: #0066cc;
      font-size: 14px;
    }

    input[type="text"],
    input[type="email"],
    input[type="password"],
    input[type="number"],
    select,
    textarea {
      padding: 10px 12px;
      border: 2px solid #0066cc;
      border-radius: 5px;
      font-size: 14px;
      font-family: Arial, sans-serif;
      transition: border-color 0.3s;
    }

    input[type="text"]:focus,
    input[type="email"]:focus,
    input[type="password"]:focus,
    input[type="number"]:focus,
    select:focus,
    textarea:focus {
      outline: none;
      border-color: #004fa3;
      box-shadow: 0 0 5px rgba(0, 102, 204, 0.3);
    }

    input[type="radio"] {
      margin-right: 6px;
      cursor: pointer;
    }

    input[type="radio"] + label {
      display: inline;
      margin-right: 15px;
      cursor: pointer;
      color: #333;
    }

    button[type="submit"] {
      padding: 12px 20px;
      background-color: #0066cc;
      color: white;
      border: none;
      border-radius: 5px;
      font-weight: 600;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s;
      margin-top: 10px;
    }

    button[type="submit"]:hover {
      background-color: #004fa3;
    }

    .links {
      margin-top: 20px;
      text-align: center;
    }

    .links a {
      padding: 8px 15px;
      background-color: #0066cc;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-size: 14px;
      margin: 0 5px;
      display: inline-block;
      transition: background-color 0.3s;
    }

    .links a:hover {
      background-color: #004fa3;
    }
  </style>
</head>
<body>
<div class="container">
  <h2>Edit Book</h2>

  <?php if ($err): ?><div class="msg error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

  <form method="post" action="../Controller/BookController.php?action=update" onsubmit="return validateBook()">
    <input type="hidden" name="id" value="<?php echo (int)$book["id"]; ?>">

    <div class="input-group">
      <label>ISBN (optional)</label>
      <input type="text" name="isbn" id="isbn" value="<?php echo htmlspecialchars($book["isbn"] ?? ""); ?>">
    </div>

    <div class="input-group">
      <label>Title</label>
      <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($book["title"]); ?>">
    </div>

    <div class="input-group">
      <label>Author</label>
      <input type="text" name="author" id="author" value="<?php echo htmlspecialchars($book["author"]); ?>">
    </div>

    <div class="input-group">
      <label>Category (optional)</label>
      <input type="text" name="category" id="category" value="<?php echo htmlspecialchars($book["category"] ?? ""); ?>">
    </div>

    <div class="input-group">
      <label>Publisher (optional)</label>
      <input type="text" name="publisher" id="publisher" value="<?php echo htmlspecialchars($book["publisher"] ?? ""); ?>">
    </div>

    <div class="input-group">
      <label>Published Year (optional)</label>
      <input type="text" name="published_year" id="published_year" value="<?php echo htmlspecialchars($book["published_year"] ?? ""); ?>">
    </div>

    <div class="input-group">
      <label>Total Copies</label>
      <input type="text" name="total_copies" id="total_copies" value="<?php echo (int)$book["total_copies"]; ?>">
    </div>

    <div class="input-group">
      <label>Available Copies</label>
      <input type="text" name="available_copies" id="available_copies" value="<?php echo (int)$book["available_copies"]; ?>">
    </div>

    <div class="input-group">
      <label>Shelf Location (optional)</label>
      <input type="text" name="shelf_location" id="shelf_location" value="<?php echo htmlspecialchars($book["shelf_location"] ?? ""); ?>">
    </div>

    <div class="input-group">
      <label>Status</label>
      <input type="radio" name="status" value="active" id="s1" <?php echo ($book["status"]==="active")?"checked":""; ?>> <label for="s1">Active</label><br>
      <input type="radio" name="status" value="inactive" id="s2" <?php echo ($book["status"]==="inactive")?"checked":""; ?>> <label for="s2">Inactive</label>
    </div>

    <div id="book_js_error" class="msg error" style="display:none;"></div>

    <button type="submit">Update</button>
  </form>

  <div class="links">
    <a href="librarian_books.php">Back to list</a> |
    <a href="dashboard.php">Dashboard</a>
  </div>
</div>

<script>
function showErr(msg){
  const box = document.getElementById("book_js_error");
  box.style.display = "block";
  box.innerText = msg;
}
function validateBook() {
  const title = document.getElementById("title").value.trim();
  const author = document.getElementById("author").value.trim();
  const year = document.getElementById("published_year").value.trim();
  const total = document.getElementById("total_copies").value.trim();
  const avail = document.getElementById("available_copies").value.trim();

  const box = document.getElementById("book_js_error");
  box.style.display = "none"; box.innerText = "";

  if (title.length < 2) return showErr("Title is required."), false;
  if (author.length < 2) return showErr("Author is required."), false;

  if (year !== "" && isNaN(year)) return showErr("Published year must be a number."), false;

  if (isNaN(total) || parseInt(total) <= 0) return showErr("Total copies must be greater than 0."), false;
  if (isNaN(avail) || parseInt(avail) < 0) return showErr("Available copies must be 0 or more."), false;

  if (parseInt(avail) > parseInt(total)) return showErr("Available cannot be more than Total."), false;

  return true;
}
</script>
</body>
</html>
