<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if (($_SESSION["user"]["role"] ?? "") !== "admin") { header("Location: dashboard.php"); exit; }

$err = $_SESSION["flash_error"] ?? "";
$ok  = $_SESSION["flash_success"] ?? "";
unset($_SESSION["flash_error"], $_SESSION["flash_success"]);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin - Users</title>
  <link rel="stylesheet" href="style.css">
  <style>
    table { width:100%; border-collapse: collapse; margin-top: 10px; }
    th, td { border-bottom: 1px solid #334155; padding: 8px; text-align:left; font-size: 14px; }
    .row-actions button { width:auto; padding:6px 10px; margin-right:6px; }
    .topbar { display:flex; gap:10px; margin-bottom:10px; }
    .topbar input, .topbar select { width:100%; }
    .btn-link { display:inline-block; margin-top:10px; }
  </style>
</head>
<body>
  <div class="container" style="max-width: 900px;">
    <h2>User Management</h2>

    <?php if ($err): ?><div class="msg error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
    <?php if ($ok): ?><div class="msg success"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>

    <div class="topbar">
      <input type="text" id="keyword" placeholder="Search by name/email" oninput="loadUsers()">
      <select id="roleFilter" onchange="loadUsers()">
        <option value="">All Roles</option>
        <option value="admin">Admin</option>
        <option value="librarian">Librarian</option>
        <option value="member">Member</option>
      </select>
    </div>

    <div class="links">
      <a href="admin_user_add.php">+ Add User</a> |
      <a href="dashboard.php">Back</a>
    </div>

    <div id="tableWrap"></div>
  </div>

<script>
function escapeHtml(text) {
  return text.replace(/[&<>"']/g, function(m) {
    return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]);
  });
}

function loadUsers() {
  const keyword = document.getElementById("keyword").value.trim();
  const role = document.getElementById("roleFilter").value;

  fetch("../Controller/AdminController.php?action=list&keyword=" + encodeURIComponent(keyword) + "&role=" + encodeURIComponent(role))
    .then(r => r.json())
    .then(data => {
      if (!data.ok) return;
      renderTable(data.users || []);
    });
}

function renderTable(users) {
  let html = `
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
  `;

  if (users.length === 0) {
    html += `<tr><td colspan="6">No users found</td></tr>`;
  } else {
    users.forEach(u => {
      const statusBtn = (u.status === "active")
        ? `<button onclick="changeStatus(${u.id}, 'blocked')">Block</button>`
        : `<button onclick="changeStatus(${u.id}, 'active')">Unblock</button>`;

      html += `
        <tr>
          <td>${u.id}</td>
          <td>${escapeHtml(u.full_name)}</td>
          <td>${escapeHtml(u.email)}</td>
          <td>${escapeHtml(u.role)}</td>
          <td>${escapeHtml(u.status)}</td>
          <td class="row-actions">${statusBtn}</td>
        </tr>
      `;
    });
  }

  html += `</tbody></table>`;
  document.getElementById("tableWrap").innerHTML = html;
}

function changeStatus(userId, status) {
  const formData = new FormData();
  formData.append("user_id", userId);
  formData.append("status", status);

  fetch("../Controller/AdminController.php?action=status", {
    method: "POST",
    body: formData
  })
  .then(r => r.json())
  .then(data => {
    if (!data.ok) {
      alert(data.msg || "Failed");
      return;
    }
    loadUsers();
  });
}

loadUsers();
</script>
</body>
</html>
