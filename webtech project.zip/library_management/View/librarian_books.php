<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
$role = $_SESSION["user"]["role"] ?? "";
if (!in_array($role, ["admin","librarian"], true)) { header("Location: dashboard.php"); exit; }

$err = $_SESSION["flash_error"] ?? "";
$ok  = $_SESSION["flash_success"] ?? "";
unset($_SESSION["flash_error"], $_SESSION["flash_success"]);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Books</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background-color: #ffffff;
      font-family: Arial, sans-serif;
      color: #333;
    }

    .container {
      max-width: 1000px;
      margin: 20px auto;
      padding: 20px;
      background-color: #f8f9ff;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 102, 204, 0.1);
    }

    h2 {
      color: #0066cc;
      margin-bottom: 15px;
      border-bottom: 3px solid #0066cc;
      padding-bottom: 10px;
    }

    .msg {
      padding: 12px 15px;
      border-radius: 5px;
      margin-bottom: 15px;
      font-weight: 500;
    }

    .msg.error {
      background-color: #ffe6e6;
      color: #cc0000;
      border-left: 4px solid #cc0000;
    }

    .msg.success {
      background-color: #e6f9ff;
      color: #0066cc;
      border-left: 4px solid #0066cc;
    }

    .topbar {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }

    .topbar input {
      flex: 1;
      min-width: 200px;
      padding: 10px 12px;
      border: 2px solid #0066cc;
      border-radius: 5px;
      font-size: 14px;
    }

    .topbar input:focus {
      outline: none;
      border-color: #004fa3;
      box-shadow: 0 0 5px rgba(0, 102, 204, 0.3);
    }

    .topbar a {
      padding: 10px 18px;
      background-color: #0066cc;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: 500;
      border: none;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .topbar a:hover {
      background-color: #004fa3;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      background-color: #ffffff;
      border-radius: 5px;
      overflow: hidden;
      box-shadow: 0 1px 3px rgba(0, 102, 204, 0.1);
    }

    th {
      background-color: #0066cc;
      color: white;
      padding: 12px;
      text-align: left;
      font-size: 14px;
      font-weight: 600;
    }

    td {
      border-bottom: 1px solid #e0e0ff;
      padding: 10px 12px;
      text-align: left;
      font-size: 14px;
    }

    tr:hover {
      background-color: #f0f4ff;
    }

    .row-actions button {
      width: auto;
      padding: 6px 12px;
      margin-right: 6px;
      background-color: #0c7ae7;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 13px;
      transition: background-color 0.3s;
    }

    .row-actions button:hover {
      background-color: #004fa3;
    }

    .row-actions button:last-child {
      background-color: #c64242;
    }

    .row-actions button:last-child:hover {
      background-color: #cc0000;
    }
  </style>
</head>
<body>
  <div class="container" style="max-width: 1000px;">
    <h2>Manage Books</h2>

    <?php if ($err): ?><div class="msg error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
    <?php if ($ok): ?><div class="msg success"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>

    <div class="topbar">
      <input type="text" id="keyword" placeholder="Search title/author/category/isbn" oninput="loadBooks()">
      <a href="librarian_book_add.php">+ Add Book</a>
      <a href="dashboard.php">Back</a>
    </div>

    <div id="tableWrap"></div>
  </div>

<script>
function escapeHtml(text) {
  return (text ?? "").toString().replace(/[&<>"']/g, m => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  }[m]));
}

function loadBooks() {
  const keyword = document.getElementById("keyword").value.trim();

  fetch("../Controller/BookController.php?action=list&keyword=" + encodeURIComponent(keyword))
    .then(r => r.json())
    .then(data => {
      if (!data.ok) return;
      renderTable(data.books || []);
    });
}

function renderTable(books) {
  let html = `
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Title</th><th>Author</th><th>Category</th>
          <th>Total</th><th>Available</th><th>Status</th><th>Actions</th>
        </tr>
      </thead>
      <tbody>
  `;

  if (books.length === 0) {
    html += `<tr><td colspan="8">No books found</td></tr>`;
  } else {
    books.forEach(b => {
      html += `
        <tr>
          <td>${b.id}</td>
          <td>${escapeHtml(b.title)}</td>
          <td>${escapeHtml(b.author)}</td>
          <td>${escapeHtml(b.category)}</td>
          <td>${b.total_copies}</td>
          <td>${b.available_copies}</td>
          <td>${escapeHtml(b.status)}</td>
          <td class="row-actions">
            <button onclick="goEdit(${b.id})">Edit</button>
            <button onclick="delBook(${b.id})">Delete</button>
          </td>
        </tr>
      `;
    });
  }

  html += `</tbody></table>`;
  document.getElementById("tableWrap").innerHTML = html;
}

function goEdit(id) {
  window.location.href = "librarian_book_edit.php?id=" + id;
}

function delBook(id) {
  if (!confirm("Delete this book?")) return;

  const fd = new FormData();
  fd.append("id", id);

  fetch("../Controller/BookController.php?action=delete", {
    method: "POST",
    body: fd
  })
  .then(r => r.json())
  .then(data => {
    if (!data.ok) { alert("Delete failed"); return; }
    loadBooks();
  });
}

loadBooks();
</script>
</body>
</html>
