<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

$err = $_SESSION["flash_error"] ?? "";
$ok  = $_SESSION["flash_success"] ?? "";
unset($_SESSION["flash_error"], $_SESSION["flash_success"]);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Change Password</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h2>Change Password</h2>

    <?php if ($err): ?>
      <div class="msg error"><?php echo htmlspecialchars($err); ?></div>
    <?php endif; ?>
    <?php if ($ok): ?>
      <div class="msg success"><?php echo htmlspecialchars($ok); ?></div>
    <?php endif; ?>

    <form method="post" action="../Controller/UserController.php?action=change_password" onsubmit="return validateChangePass()">
      <div class="input-group">
        <label>Current Password</label>
        <input type="password" id="current_password" name="current_password" placeholder="current password">
      </div>

      <div class="input-group">
        <label>New Password</label>
        <input type="password" id="new_password" name="new_password" placeholder="min 6 characters">
      </div>

      <div class="input-group">
        <label>Confirm New Password</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="repeat new password">
      </div>

      <div id="pass_js_error" class="msg error" style="display:none;"></div>

      <button type="submit">Update Password</button>
    </form>

    <div class="links">
      <a href="profile.php">Back to Profile</a> |
      <a href="dashboard.php">Back to Dashboard</a>
    </div>
  </div>

<script>
function validateChangePass() {
  const cur = document.getElementById("current_password").value;
  const np  = document.getElementById("new_password").value;
  const cp  = document.getElementById("confirm_password").value;

  const box = document.getElementById("pass_js_error");
  box.style.display = "none";
  box.innerText = "";

  if (cur === "" || np === "" || cp === "") {
    box.style.display = "block";
    box.innerText = "All password fields are required.";
    return false;
  }

  if (np.length < 6) {
    box.style.display = "block";
    box.innerText = "New password must be at least 6 characters.";
    return false;
  }

  if (np !== cp) {
    box.style.display = "block";
    box.innerText = "New password and confirm password do not match.";
    return false;
  }

  return true;
}
</script>
</body>
</html>
