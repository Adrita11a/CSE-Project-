<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
$user = $_SESSION["user"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<style>

body {font-family:Arial,sans-serif;background:#f4f4f9;margin:0;padding:20px}


.top-bar {display:flex;justify-content:space-between;align-items:center;background:#007BFF;color:#fff;padding:15px 20px;border-radius:10px 10px 0 0;margin-bottom:20px}
.top-bar h2 {margin:0}
.top-bar .role {font-weight:normal;font-size:0.9em}


h1 {color:#000;margin-bottom:15px;font-size:1.5em}


.menu {display:flex;flex-wrap:wrap;gap:15px}
.menu a {
    display:inline-block;padding:15px 25px;background:#007BFF;color:#fff;text-decoration:none;font-weight:bold;
    border-radius:10px;transition:background 0.3s,transform 0.2s;flex:1 1 200px;text-align:center
}
.menu a:hover {background:#0056b3;transform:translateY(-3px)}


.card-container {display:flex;flex-wrap:wrap;gap:20px;margin-bottom:30px}
.card {flex:1 1 200px;background:#fff;padding:20px;border-radius:10px;position:relative;
       box-shadow:0 2px 8px rgba(0,0,0,0.1);text-align:center;transition:transform 0.2s}
.card:hover {transform:translateY(-5px)}
.card p {font-weight:bold;margin-bottom:10px;color:#555}
.card h2 {font-size:36px;margin:0}
.dot {position:absolute;top:15px;right:15px;width:15px;height:15px;border-radius:50%}
.dot.blue {background:#007BFF}
.dot.orange {background:#fd7e14}
.dot.green {background:#28a745}
.dot.purple {background:#6f42c1}
</style>
</head>
<body>

<div class="top-bar">
    <h2>Welcome, <?php echo htmlspecialchars($user["full_name"]); ?></h2>
    <span class="role">Role: <?php echo htmlspecialchars($user["role"]); ?></span>
</div>

<h1>Dashboard</h1>


<div class="menu">
  <?php if ($user["role"] === "admin"): ?>
      <a href="admin_users.php">User Management</a>
      <a href="admin_reports.php">Reports</a>
      <a href="admin_settings.php">System Settings</a>
  <?php elseif ($user["role"] === "librarian"): ?>
      <a href="librarian_books.php">Manage Books</a>
      <a href="borrow_requests.php">Borrow Requests</a>
      <a href="issue_book.php">Issue Book</a>
      <a href="fines.php">Manage Fines</a>
  <?php else: ?>
      <a href="search_books.php">Search Books</a>
      <a href="my_requests.php">My Requests</a>
      <a href="my_issued_history.php">Issued Book History</a>
  <?php endif; ?>

  <a href="profile.php">Profile</a>
  <a href="../Controller/AuthController.php?action=logout">Logout</a>
</div>

</body>
</html>
