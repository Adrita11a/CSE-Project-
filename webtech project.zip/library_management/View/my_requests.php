<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
if (($_SESSION["user"]["role"] ?? "") !== "member") { header("Location: dashboard.php"); exit; }

require_once __DIR__ . "/../Model/Member.php";

$memberId = (int)$_SESSION["user"]["id"];
$rows = member_getMyRequests($memberId);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Borrow Requests</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f4f4f9;
    margin: 0;
    padding: 15px;
}

.container {
    max-width: 800px;
    margin: auto;
}

/* Heading */
h2 {
    color: #007BFF;
    margin-bottom: 15px;
    font-size: 1.2em;
}

/* Table */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 6px;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
th, td {
    padding: 6px 8px;
    font-size: 13px;
    border-bottom: 1px solid #ccc;
}
th {
    background: #007BFF;
    color: #fff;
    text-align: left;
}
tr:hover {
    background: #e6f0ff;
}

/* Status tags */
.tag {
    display: inline-block;
    padding: 2px 6px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
}
.pending { background: rgba(234,179,8,.15); border:1px solid rgba(234,179,8,.35); color:#b45309; }
.approved { background: rgba(34,197,94,.15); border:1px solid rgba(34,197,94,.35); color:#166534; }
.rejected { background: rgba(239,68,68,.15); border:1px solid rgba(239,68,68,.35); color:#991b1b; }

/* Back link */
.links a {
    display: inline-block;
    margin-top: 10px;
    padding: 5px 10px;
    text-decoration: none;
    background: #007BFF;
    color: #fff;
    font-size: 12px;
    border-radius: 5px;
}
.links a:hover {
    background: #0056b3;
}
</style>
</head>
<body>

<div class="container">

<h2>My Borrow Requests</h2>

<table>
    <tr>
        <th>Book</th>
        <th>Request Date</th>
        <th>Status</th>
        <th>Processed At</th>
    </tr>

    <?php if (empty($rows)): ?>
        <tr><td colspan="4" style="text-align:center;">No requests found.</td></tr>
    <?php else: foreach ($rows as $r): ?>
        <tr>
            <td>
                <b><?= htmlspecialchars($r["book_title"]) ?></b><br>
                <small><?= htmlspecialchars($r["author"] ?? "") ?></small>
            </td>
            <td><?= htmlspecialchars($r["request_date"]) ?></td>
            <td>
                <?php if ($r["status"] === "pending"): ?>
                    <span class="tag pending">Pending</span>
                <?php elseif ($r["status"] === "approved"): ?>
                    <span class="tag approved">Approved</span>
                <?php else: ?>
                    <span class="tag rejected">Rejected</span>
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($r["processed_at"] ?? "-") ?></td>
        </tr>
    <?php endforeach; endif; ?>
</table>

<div class="links">
    <a href="dashboard.php">Back</a>
</div>

</div>
</body>
</html>
