<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: login.php"); exit; }
$role = $_SESSION["user"]["role"] ?? "";
if (!in_array($role, ["admin","librarian"], true)) { header("Location: dashboard.php"); exit; }

require_once __DIR__ . "/../Model/Fine.php";
$rows = fine_getAllFines();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Fines</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background-color: #ffffff;
      font-family: Arial, sans-serif;
      color: #333;
    }

    .container {
      max-width: 1100px;
      margin: 20px auto;
      padding: 20px;
      background-color: #f8f9ff;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 102, 204, 0.1);
    }

    h2 {
      color: #0066cc;
      margin-bottom: 15px;
      border-bottom: 3px solid #0066cc;
      padding-bottom: 10px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      background-color: #ffffff;
      border-radius: 5px;
      overflow: hidden;
      box-shadow: 0 1px 3px rgba(0, 102, 204, 0.1);
    }

    th {
      background-color: #0066cc;
      color: white;
      padding: 12px;
      text-align: left;
      font-size: 14px;
      font-weight: 600;
    }

    td {
      border-bottom: 1px solid #e0e0ff;
      padding: 10px 12px;
      text-align: left;
      font-size: 14px;
    }

    tr:hover {
      background-color: #f0f4ff;
    }

    button {
      width: auto;
      padding: 6px 12px;
      background-color: #0066cc;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 13px;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #004fa3;
    }

    .paid {
      color: #009900;
      font-weight: 600;
    }

    .unpaid {
      color: #cc0000;
      font-weight: 600;
    }

    .links {
      margin-top: 15px;
    }

    .links a {
      padding: 10px 18px;
      background-color: #0066cc;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: 500;
      display: inline-block;
      transition: background-color 0.3s;
    }

    .links a:hover {
      background-color: #004fa3;
    }
  </style>
</head>
<body>
<div class="container" style="max-width:1100px;">
  <h2>Manage Fines</h2>

  <table>
    <tr>
      <th>Fine ID</th><th>Member</th><th>Book</th><th>Issue ID</th><th>Amount</th><th>Status</th><th>Action</th>
    </tr>

    <?php if (empty($rows)): ?>
      <tr><td colspan="7">No fines found.</td></tr>
    <?php else: foreach($rows as $r): ?>
      <tr>
        <td><?php echo (int)$r["id"]; ?></td>
        <td><?php echo htmlspecialchars($r["member_name"]); ?></td>
        <td><?php echo htmlspecialchars($r["book_title"]); ?></td>
        <td><?php echo (int)$r["issue_id"]; ?></td>
        <td><?php echo htmlspecialchars($r["amount"]); ?></td>
        <td>
          <?php if ($r["paid"] === "yes"): ?>
            <b class="paid">Paid</b>
          <?php else: ?>
            <b class="unpaid">Unpaid</b>
          <?php endif; ?>
        </td>
        <td>
          <?php if ($r["paid"] === "no"): ?>
            <button onclick="payFine(<?php echo (int)$r['id']; ?>)">Mark Paid</button>
          <?php else: ?>
            -
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; endif; ?>
  </table>

  <div class="links" style="margin-top:10px;">
    <a href="dashboard.php">Back</a>
  </div>
</div>

<script>
function payFine(id){
  if(!confirm("Mark this fine as paid?")) return;

  const fd = new FormData();
  fd.append("fine_id", id);

  fetch("../Controller/FineController.php?action=pay",{
    method:"POST",
    body:fd
  })
  .then(r=>r.json())
  .then(d=>{
    if(d.ok) location.reload();
    else alert("Failed");
  });
}
</script>
</body>
</html>
