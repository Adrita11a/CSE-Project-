<?php
session_start();
if (isset($_SESSION["user"])) {
    header("Location: dashboard.php");
    exit;
}

$err = $_SESSION["flash_error"] ?? "";
$ok  = $_SESSION["flash_success"] ?? "";
unset($_SESSION["flash_error"], $_SESSION["flash_success"]);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login - Library Management System</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background-color: #ffffff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .header {
      background-color: #0066cc;
      color: white;
      padding: 20px 0;
      text-align: center;
      box-shadow: 0 2px 8px rgba(0, 102, 204, 0.15);
    }

    .header h1 {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 5px;
    }

    .header p {
      font-size: 14px;
      opacity: 0.9;
    }

    .login-wrapper {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      padding: 40px 20px;
    }

    .container {
      max-width: 450px;
      width: 100%;
      padding: 45px;
      background-color: #ffffff;
      border-radius: 10px;
      box-shadow: 0 8px 32px rgba(0, 102, 204, 0.25);
      border-top: 6px solid #0066cc;
      position: relative;
    }

    h2 {
      color: #0066cc;
      margin-bottom: 25px;
      text-align: center;
      font-size: 24px;
      font-weight: 600;
    }

    .msg {
      padding: 12px 15px;
      border-radius: 5px;
      margin-bottom: 15px;
      font-weight: 500;
      font-size: 14px;
    }

    .msg.error {
      background-color: #ffe6e6;
      color: #cc0000;
      border-left: 4px solid #cc0000;
    }

    .msg.success {
      background-color: #e6f9ff;
      color: #0066cc;
      border-left: 4px solid #0066cc;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .input-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    label {
      font-weight: 600;
      color: #0066cc;
      font-size: 14px;
    }

    input[type="text"],
    input[type="password"] {
      padding: 12px 14px;
      border: 1px solid #d0d0d0;
      border-radius: 5px;
      font-size: 14px;
      font-family: Arial, sans-serif;
      transition: all 0.3s;
      background-color: #fafafa;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
      outline: none;
      border-color: #0066cc;
      background-color: #ffffff;
      box-shadow: 0 0 5px rgba(0, 102, 204, 0.2);
    }

    button[type="submit"] {
      padding: 12px 20px;
      background-color: #0066cc;
      color: white;
      border: none;
      border-radius: 5px;
      font-weight: 600;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s;
      margin-top: 10px;
    }

    button[type="submit"]:hover {
      background-color: #004fa3;
    }

    .links {
      margin-top: 25px;
      text-align: center;
      border-top: 1px solid #e0e0e0;
      padding-top: 20px;
    }

    .links a {
      color: #0066cc;
      text-decoration: none;
      font-size: 14px;
      margin: 0 8px;
      transition: color 0.3s;
    }

    .links a:hover {
      color: #004fa3;
      text-decoration: underline;
    }
  </style>
</head>
</head>
<body>
  <div class="header">
    <h1> Library Management System</h1>
    <p></p>
  </div>

  <div class="login-wrapper">
    <div class="container">
      <h2>Login</h2>

      <?php if ($err): ?>
        <div class="msg error"><?php echo htmlspecialchars($err); ?></div>
      <?php endif; ?>
      <?php if ($ok): ?>
        <div class="msg success"><?php echo htmlspecialchars($ok); ?></div>
      <?php endif; ?>

      <form method="post" action="../Controller/AuthController.php" onsubmit="return validateLogin()">
        <input type="hidden" name="form_type" value="login">

        <div class="input-group">
          <label>Email</label>
          <input type="text" name="email" id="login_email" placeholder="example@mail.com">
        </div>

        <div class="input-group">
          <label>Password</label>
          <input type="password" name="password" id="login_password" placeholder="******">
        </div>

        <div id="login_js_error" class="msg error" style="display:none;"></div>

        <button type="submit">Login</button>
      </form>

      <div class="links">
        <a href="register.php">Create account</a> |
        <a href="forgot_password.php">Forgot password</a>
      </div>
    </div>
  </div>

<script>
function validateLogin() {
  const email = document.getElementById("login_email").value.trim();
  const pass  = document.getElementById("login_password").value;

  const box = document.getElementById("login_js_error");
  box.style.display = "none";
  box.innerText = "";

  if (email === "") {
    box.style.display = "block";
    box.innerText = "Email is required.";
    return false;
  }

  // basic email format check
  if (!email.includes("@") || !email.includes(".")) {
    box.style.display = "block";
    box.innerText = "Please enter a valid email.";
    return false;
  }

  if (pass === "") {
    box.style.display = "block";
    box.innerText = "Password is required.";
    return false;
  }

  return true;
}
</script>
</body>
</html>
