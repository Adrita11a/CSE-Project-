<?php
require_once __DIR__ . "/db.php";

function book_getAll(string $keyword = ""): array
{
    global $conn;
    $like = "%" . trim($keyword) . "%";

    $sql = "SELECT id, isbn, title, author, category, publisher, published_year,
                   total_copies, available_copies, shelf_location, status, created_at
            FROM books
            WHERE (title LIKE ? OR author LIKE ? OR category LIKE ? OR isbn LIKE ?)
            ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $like, $like, $like, $like);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    $stmt->close();
    return $rows;
}

function book_findById(int $id): ?array
{
    global $conn;
    $sql = "SELECT * FROM books WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function book_create(array $data): bool
{
    global $conn;

    $sql = "INSERT INTO books (
                isbn, title, author, category, publisher, published_year,
                total_copies, available_copies, shelf_location, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $isbn      = $data["isbn"] ?? null;
    $title     = $data["title"];
    $author    = $data["author"];
    $category  = $data["category"] ?? null;
    $publisher = $data["publisher"] ?? null;
    $year      = (int)($data["published_year"] ?? 0);
    $total     = (int)($data["total_copies"] ?? 1);
    $avail     = (int)($data["available_copies"] ?? 1);
    $shelf     = $data["shelf_location"] ?? null;
    $status    = $data["status"] ?? "active";

    $stmt->bind_param(
        "sssssiiiss",
        $isbn, $title, $author, $category, $publisher,
        $year, $total, $avail, $shelf, $status
    );

    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function book_update(int $id, array $data): bool
{
    global $conn;

    $sql = "UPDATE books
            SET isbn=?, title=?, author=?, category=?, publisher=?, published_year=?,
                total_copies=?, available_copies=?, shelf_location=?, status=?
            WHERE id=? LIMIT 1";

    $stmt = $conn->prepare($sql);

    $types = "sssssiiissi";
    $stmt->bind_param(
        $types,
        $data["isbn"], $data["title"], $data["author"], $data["category"], $data["publisher"],
        $data["published_year"], $data["total_copies"], $data["available_copies"],
        $data["shelf_location"], $data["status"],
        $id
    );

    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function book_delete(int $id): bool
{
    global $conn;
    $sql = "DELETE FROM books WHERE id=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}
