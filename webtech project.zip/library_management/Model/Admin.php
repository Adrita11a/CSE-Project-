<?php
require_once __DIR__ . "/db.php";

function admin_getUsers(string $keyword = "", string $role = ""): array
{
    global $conn;

    $keywordLike = "%" . $keyword . "%";

    $sql = "SELECT id, full_name, email, phone, role, status, created_at
            FROM users
            WHERE (full_name LIKE ? OR email LIKE ?)";

    $types = "ss";
    $params = [$keywordLike, $keywordLike];

    if ($role !== "" && in_array($role, ["admin", "librarian", "member"], true)) {
        $sql .= " AND role = ?";
        $types .= "s";
        $params[] = $role;
    }

    $sql .= " ORDER BY id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = [];
    while ($r = $res->fetch_assoc()) {
        $rows[] = $r;
    }
    $stmt->close();

    return $rows;
}

function admin_createUser(string $fullName, string $email, string $phone, string $password, string $role): bool
{
    global $conn;

    $hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (full_name, email, phone, role, password_hash, status)
            VALUES (?, ?, ?, ?, ?, 'active')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $fullName, $email, $phone, $role, $hash);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function admin_setUserStatus(int $userId, string $status): bool
{
    global $conn;

    if (!in_array($status, ["active", "blocked"], true)) {
        return false;
    }

    $sql = "UPDATE users SET status = ? WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $userId);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function admin_emailExists(string $email): bool
{
    global $conn;
    $sql = "SELECT id FROM users WHERE email = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    $exists = $res->num_rows > 0;
    $stmt->close();
    return $exists;
}
