<?php
require_once __DIR__ . "/db.php";

function fine_upsertFine(int $issueId, int $memberId, float $amount): bool
{
    global $conn;

    $sql = "INSERT INTO fines (issue_id, member_id, amount, paid)
            VALUES (?, ?, ?, 'no')
            ON DUPLICATE KEY UPDATE amount = VALUES(amount)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iid", $issueId, $memberId, $amount);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function fine_markPaid(int $fineId): bool
{
    global $conn;
    $sql = "UPDATE fines SET paid='yes', paid_at=NOW() WHERE id=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $fineId);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function fine_getAllFines(): array
{
    global $conn;
    $sql = "SELECT f.id, f.amount, f.paid, f.paid_at,
                   u.full_name AS member_name,
                   b.title AS book_title,
                   i.id AS issue_id
            FROM fines f
            JOIN users u ON u.id = f.member_id
            JOIN issues i ON i.id = f.issue_id
            JOIN books b ON b.id = i.book_id
            ORDER BY f.id DESC";
    $res = $conn->query($sql);

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
}
