<?php
require_once __DIR__ . "/db.php";

function setting_get(string $key, string $default = ""): string
{
    global $conn;
    $sql = "SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return $row ? (string)$row["setting_value"] : $default;
}
