<?php
require_once __DIR__ . "/db.php";

function report_dashboardCounts(): array
{
    global $conn;

    $counts = [
        "total_users" => 0,
        "total_books" => 0,
        "total_requests" => 0,
        "pending_requests" => 0,
        "issued_now" => 0,
        "total_fines" => 0,
        "unpaid_fines" => 0,
        "total_fine_amount" => "0.00",
        "unpaid_fine_amount" => "0.00",
    ];

    $counts["total_users"] = (int)$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()["c"];
    $counts["total_books"] = (int)$conn->query("SELECT COUNT(*) c FROM books")->fetch_assoc()["c"];
    $counts["total_requests"] = (int)$conn->query("SELECT COUNT(*) c FROM borrow_requests")->fetch_assoc()["c"];
    $counts["pending_requests"] = (int)$conn->query("SELECT COUNT(*) c FROM borrow_requests WHERE status='pending'")->fetch_assoc()["c"];
    $counts["issued_now"] = (int)$conn->query("SELECT COUNT(*) c FROM issues WHERE status='issued'")->fetch_assoc()["c"];
    $counts["total_fines"] = (int)$conn->query("SELECT COUNT(*) c FROM fines")->fetch_assoc()["c"];
    $counts["unpaid_fines"] = (int)$conn->query("SELECT COUNT(*) c FROM fines WHERE paid='no'")->fetch_assoc()["c"];

    $row1 = $conn->query("SELECT COALESCE(SUM(amount),0) s FROM fines")->fetch_assoc();
    $counts["total_fine_amount"] = number_format((float)$row1["s"], 2, ".", "");

    $row2 = $conn->query("SELECT COALESCE(SUM(amount),0) s FROM fines WHERE paid='no'")->fetch_assoc();
    $counts["unpaid_fine_amount"] = number_format((float)$row2["s"], 2, ".", "");

    return $counts;
}

function report_latestIssues(int $limit = 10): array
{
    global $conn;
    $limit = max(1, min(50, $limit));

    $sql = "SELECT i.id, i.issue_date, i.due_date, i.return_date, i.status,
                   u.full_name AS member_name,
                   b.title AS book_title
            FROM issues i
            JOIN users u ON u.id = i.member_id
            JOIN books b ON b.id = i.book_id
            ORDER BY i.id DESC
            LIMIT $limit";

    $res = $conn->query($sql);
    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
}
