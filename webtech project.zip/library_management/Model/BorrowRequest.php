<?php
require_once __DIR__ . "/db.php";

function borrowRequest_create(int $memberId, int $bookId): array
{
    global $conn;

    $sql = "SELECT id, available_copies, status FROM books WHERE id=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $bookId);
    $stmt->execute();
    $res = $stmt->get_result();
    $book = $res->fetch_assoc();
    $stmt->close();

    if (!$book) return ["ok"=>false, "msg"=>"Book not found"];
    if (($book["status"] ?? "active") !== "active") return ["ok"=>false, "msg"=>"Book is inactive"];
    if ((int)$book["available_copies"] <= 0) return ["ok"=>false, "msg"=>"No copies available"];

    $sql = "SELECT id FROM borrow_requests
            WHERE member_id=? AND book_id=? AND status='pending'
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $memberId, $bookId);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $stmt->close();
        return ["ok"=>false, "msg"=>"You already have a pending request for this book"];
    }
    $stmt->close();

    $sql = "INSERT INTO borrow_requests (member_id, book_id, status)
            VALUES (?, ?, 'pending')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $memberId, $bookId);

    $ok = $stmt->execute();
    $err = $stmt->error;
    $stmt->close();

    if (!$ok) return ["ok"=>false, "msg"=>"DB error: " . $err];

    return ["ok"=>true, "msg"=>"Request sent successfully"];
}

function borrowRequest_getAllPending(): array
{
    global $conn;

    $sql = "SELECT br.id, br.request_date,
                   u.full_name AS member_name,
                   b.title AS book_title
            FROM borrow_requests br
            JOIN users u ON u.id = br.member_id
            JOIN books b ON b.id = br.book_id
            WHERE br.status = 'pending'
            ORDER BY br.id DESC";

    $res = $conn->query($sql);
    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
}

function borrowRequest_updateStatus(int $id, string $status, int $librarianId): bool
{
    global $conn;

    if (!in_array($status, ["approved","rejected"], true)) return false;

    $sql = "UPDATE borrow_requests
            SET status=?, processed_by=?, processed_at=NOW()
            WHERE id=? AND status='pending'
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $status, $librarianId, $id);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}
