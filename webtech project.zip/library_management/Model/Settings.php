<?php
require_once __DIR__ . "/db.php";

function settings_getAll(): array
{
    global $conn;
    $res = $conn->query("SELECT setting_key, setting_value FROM settings");
    $out = [];
    while ($r = $res->fetch_assoc()) {
        $out[$r["setting_key"]] = $r["setting_value"];
    }
    return $out;
}

function settings_set(string $key, string $value): bool
{
    global $conn;
    $sql = "INSERT INTO settings (setting_key, setting_value)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $key, $value);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}
