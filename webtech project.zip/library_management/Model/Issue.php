<?php
require_once __DIR__ . "/db.php";

function issue_getApprovedNotIssued(): array
{
    global $conn;

    $sql = "SELECT br.id AS request_id, br.member_id, br.book_id, br.request_date,
                   u.full_name AS member_name, u.email AS member_email,
                   b.title AS book_title, b.available_copies
            FROM borrow_requests br
            JOIN users u ON u.id = br.member_id
            JOIN books b ON b.id = br.book_id
            WHERE br.status='approved'
              AND (br.note IS NULL OR br.note <> 'issued')
            ORDER BY br.id DESC";

    $res = $conn->query($sql);
    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
}

function issue_issueFromRequest(int $requestId, int $issuedBy, int $maxDays): array
{
    global $conn;

    $sql = "SELECT br.id, br.member_id, br.book_id, br.status, br.note,
                   b.available_copies
            FROM borrow_requests br
            JOIN books b ON b.id = br.book_id
            WHERE br.id=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $requestId);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();

    if (!$row) return ["ok"=>false, "msg"=>"Request not found"];
    if ($row["status"] !== "approved") return ["ok"=>false, "msg"=>"Request is not approved"];
    if (($row["note"] ?? "") === "issued") return ["ok"=>false, "msg"=>"Already issued"];
    if ((int)$row["available_copies"] <= 0) return ["ok"=>false, "msg"=>"No available copies"];

    $memberId = (int)$row["member_id"];
    $bookId   = (int)$row["book_id"];

    $conn->begin_transaction();

    try {
        $issueDate = date("Y-m-d H:i:s");
        $dueDate   = date("Y-m-d H:i:s", strtotime("+$maxDays days"));

        $sql = "INSERT INTO issues (member_id, book_id, issued_by, issue_date, due_date, status)
                VALUES (?, ?, ?, ?, ?, 'issued')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiss", $memberId, $bookId, $issuedBy, $issueDate, $dueDate);
        $ok1 = $stmt->execute();
        $stmt->close();

        if (!$ok1) throw new Exception("Issue insert failed");

        $sql = "UPDATE books
                SET available_copies = available_copies - 1
                WHERE id=? AND available_copies > 0
                LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $bookId);
        $ok2 = $stmt->execute();
        $stmt->close();

        if (!$ok2) throw new Exception("Book stock update failed");

        $sql = "UPDATE borrow_requests
                SET note='issued'
                WHERE id=? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $requestId);
        $ok3 = $stmt->execute();
        $stmt->close();

        if (!$ok3) throw new Exception("Request update failed");

        $conn->commit();
        return ["ok"=>true, "msg"=>"Book issued successfully", "due_date"=>$dueDate];
    } catch (Exception $e) {
        $conn->rollback();
        return ["ok"=>false, "msg"=>$e->getMessage()];
    }
}

function issue_getIssuedByMember(int $memberId): array
{
    global $conn;
    $sql = "SELECT i.id, i.issue_date, i.due_date, i.return_date, i.status,
                   b.title, b.author, b.category
            FROM issues i
            JOIN books b ON b.id = i.book_id
            WHERE i.member_id = ?
            ORDER BY i.id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $memberId);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    $stmt->close();
    return $rows;
}

function issue_getAllCurrentlyIssued(): array
{
    global $conn;
    $sql = "SELECT i.id, i.issue_date, i.due_date,
                   u.full_name AS member_name, u.email AS member_email,
                   b.title AS book_title
            FROM issues i
            JOIN users u ON u.id = i.member_id
            JOIN books b ON b.id = i.book_id
            WHERE i.status='issued'
            ORDER BY i.id DESC";
    $res = $conn->query($sql);

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
}

function issue_getIssuedListForReturn(string $keyword = ""): array
{
    global $conn;
    $like = "%" . trim($keyword) . "%";

    $sql = "SELECT i.id AS issue_id, i.issue_date, i.due_date,
                   u.full_name AS member_name, u.email AS member_email,
                   b.title AS book_title
            FROM issues i
            JOIN users u ON u.id = i.member_id
            JOIN books b ON b.id = i.book_id
            WHERE i.status='issued'
              AND (u.full_name LIKE ? OR u.email LIKE ? OR b.title LIKE ?)
            ORDER BY i.id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    $stmt->close();
    return $rows;
}

function issue_returnBook(int $issueId, float $finePerDay): array
{
    global $conn;

    $sql = "SELECT id, member_id, book_id, due_date, status
            FROM issues WHERE id=? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $issueId);
    $stmt->execute();
    $res = $stmt->get_result();
    $issue = $res->fetch_assoc();
    $stmt->close();

    if (!$issue) return ["ok"=>false, "msg"=>"Issue not found"];
    if ($issue["status"] !== "issued") return ["ok"=>false, "msg"=>"Already returned"];

    $memberId = (int)$issue["member_id"];
    $bookId   = (int)$issue["book_id"];
    $dueDate  = strtotime($issue["due_date"]);
    $now      = time();

    $lateDays = 0;
    if ($now > $dueDate) {
        $diffSeconds = $now - $dueDate;
        $lateDays = (int)ceil($diffSeconds / 86400);
    }
    $fineAmount = $lateDays * $finePerDay;

    $conn->begin_transaction();
    try {
        $returnDate = date("Y-m-d H:i:s");
        $sql = "UPDATE issues SET return_date=?, status='returned' WHERE id=? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $returnDate, $issueId);
        $ok1 = $stmt->execute();
        $stmt->close();
        if (!$ok1) throw new Exception("Issue update failed");

        $sql = "UPDATE books SET available_copies = available_copies + 1 WHERE id=? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $bookId);
        $ok2 = $stmt->execute();
        $stmt->close();
        if (!$ok2) throw new Exception("Book stock update failed");

        if ($fineAmount > 0) {
            require_once __DIR__ . "/Fine.php";
            $ok3 = fine_upsertFine($issueId, $memberId, $fineAmount);
            if (!$ok3) throw new Exception("Fine update failed");
        }

        $conn->commit();
        return ["ok"=>true, "msg"=>"Returned successfully", "late_days"=>$lateDays, "fine"=>$fineAmount];
    } catch (Exception $e) {
        $conn->rollback();
        return ["ok"=>false, "msg"=>$e->getMessage()];
    }
}
