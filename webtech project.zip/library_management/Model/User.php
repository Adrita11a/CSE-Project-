<?php
require_once __DIR__ . "/db.php";

function user_findByEmail(string $email): ?array
{
    global $conn;
    $sql = "SELECT id, full_name, email, role, password_hash, status FROM users WHERE email = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function user_create(string $fullName, string $email, string $phone, string $password, string $role = "member"): bool
{
    global $conn;

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (full_name, email, phone, role, password_hash, status)
            VALUES (?, ?, ?, ?, ?, 'active')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $fullName, $email, $phone, $role, $passwordHash);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}

function user_verifyLogin(string $email, string $password): array
{
    $user = user_findByEmail($email);

    if (!$user) {
        return ["ok" => false, "msg" => "Invalid email or password"];
    }

    if ($user["status"] !== "active") {
        return ["ok" => false, "msg" => "Your account is blocked"];
    }

    if (!password_verify($password, $user["password_hash"])) {
        return ["ok" => false, "msg" => "Invalid email or password"];
    }

    unset($user["password_hash"]);
    return ["ok" => true, "user" => $user];
}

function user_findById(int $id): ?array
{
    global $conn;
    $sql = "SELECT id, full_name, email, phone, role, status, created_at FROM users WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function user_updateProfile(int $id, string $fullName, string $phone): bool
{
    global $conn;
    $sql = "UPDATE users SET full_name = ?, phone = ? WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $fullName, $phone, $id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function user_changePassword(int $id, string $newPassword): bool
{
    global $conn;
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);

    $sql = "UPDATE users SET password_hash = ? WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $hash, $id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function user_getPasswordHashById(int $id): ?string
{
    global $conn;
    $sql = "SELECT password_hash FROM users WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return $row ? $row["password_hash"] : null;
}
