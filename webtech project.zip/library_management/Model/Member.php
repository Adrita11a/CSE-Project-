<?php
require_once __DIR__ . "/db.php";

function member_getMyRequests(int $memberId): array
{
    global $conn;

    $sql = "SELECT br.id, br.request_date, br.status, br.processed_at,
                   b.title AS book_title, b.author
            FROM borrow_requests br
            JOIN books b ON b.id = br.book_id
            WHERE br.member_id = ?
            ORDER BY br.id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $memberId);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    $stmt->close();
    return $rows;
}
