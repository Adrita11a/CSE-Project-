<?php
session_start();
require_once __DIR__ . "/../Model/Settings.php";

if (!isset($_SESSION["user"])) {
    header("Location: ../View/login.php");
    exit;
}
if (($_SESSION["user"]["role"] ?? "") !== "admin") {
    header("Location: ../View/dashboard.php");
    exit;
}

function clean(string $s): string { return trim($s); }

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../View/admin_settings.php");
    exit;
}

$maxDays = (int)($_POST["max_borrow_days"] ?? 0);
$finePerDay = (float)($_POST["fine_per_day"] ?? 0);

if ($maxDays <= 0 || $maxDays > 60) {
    $_SESSION["flash_error"] = "Max borrow days must be between 1 and 60.";
    header("Location: ../View/admin_settings.php");
    exit;
}

if ($finePerDay < 0 || $finePerDay > 10000) {
    $_SESSION["flash_error"] = "Fine per day must be between 0 and 10000.";
    header("Location: ../View/admin_settings.php");
    exit;
}


$ok1 = settings_set("max_borrow_days", (string)$maxDays);
$ok2 = settings_set("fine_per_day", (string)$finePerDay);

if ($ok1 && $ok2) {
    $_SESSION["flash_success"] = "Settings updated successfully.";
} else {
    $_SESSION["flash_error"] = "Failed to update settings.";
}

header("Location: ../View/admin_settings.php");
exit;
