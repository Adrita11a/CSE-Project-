<?php
// Controller/AuthController.php
session_start();
require_once __DIR__ . "/../Model/User.php";

function clean(string $s): string {
    return trim($s);
}

$action = $_GET["action"] ?? "";

if ($action === "check_email") {
    header("Content-Type: application/json; charset=utf-8");
    $email = clean($_GET["email"] ?? "");
    $exists = false;

    if ($email !== "" && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $u = user_findByEmail($email);
        $exists = $u ? true : false;
    }
    echo json_encode(["exists" => $exists]);
    exit;
}

if ($action === "logout") {
    session_destroy();
    header("Location: ../View/login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../View/login.php");
    exit;
}

$formType = $_POST["form_type"] ?? "";

if ($formType === "register") {
    $fullName = clean($_POST["full_name"] ?? "");
    $email    = clean($_POST["email"] ?? "");
    $phone    = clean($_POST["phone"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm  = $_POST["confirm_password"] ?? "";

    // PHP validation
    if ($fullName === "" || strlen($fullName) < 3) {
        $_SESSION["flash_error"] = "Full name must be at least 3 characters.";
        header("Location: ../View/register.php");
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION["flash_error"] = "Invalid email format.";
        header("Location: ../View/register.php");
        exit;
    }

    if (strlen($password) < 6) {
        $_SESSION["flash_error"] = "Password must be at least 6 characters.";
        header("Location: ../View/register.php");
        exit;
    }

    if ($password !== $confirm) {
        $_SESSION["flash_error"] = "Passwords do not match.";
        header("Location: ../View/register.php");
        exit;
    }

    if (user_findByEmail($email)) {
        $_SESSION["flash_error"] = "Email already exists. Please login.";
        header("Location: ../View/register.php");
        exit;
    }

    $ok = user_create($fullName, $email, $phone, $password, "member");

    if ($ok) {
        $_SESSION["flash_success"] = "Registration successful! Please login.";
        header("Location: ../View/login.php");
        exit;
    }

    $_SESSION["flash_error"] = "Registration failed. Try again.";
    header("Location: ../View/register.php");
    exit;
}

if ($formType === "login") {
    $email    = clean($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION["flash_error"] = "Invalid email format.";
        header("Location: ../View/login.php");
        exit;
    }
    if ($password === "") {
        $_SESSION["flash_error"] = "Password is required.";
        header("Location: ../View/login.php");
        exit;
    }

    $result = user_verifyLogin($email, $password);

    if ($result["ok"]) {
        $_SESSION["user"] = $result["user"]; // id, name, email, role
        header("Location: ../View/dashboard.php");
        exit;
    }

    $_SESSION["flash_error"] = $result["msg"];
    header("Location: ../View/login.php");
    exit;
}

// fallback
header("Location: ../View/login.php");
exit;
