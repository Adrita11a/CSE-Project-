<?php
session_start();
require_once __DIR__ . "/../Model/User.php";

function clean(string $s): string {
    return trim($s);
}

if (!isset($_SESSION["user"])) {
    header("Location: ../View/login.php");
    exit;
}

$action = $_GET["action"] ?? "";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../View/dashboard.php");
    exit;
}

$userId = (int)$_SESSION["user"]["id"];

if ($action === "update_profile") {
    header("Content-Type: application/json; charset=utf-8");

    $fullName = clean($_POST["full_name"] ?? "");
    $phone    = clean($_POST["phone"] ?? "");

    if ($fullName === "" || strlen($fullName) < 3) {
        echo json_encode(["ok"=>false, "msg"=>"Full name must be at least 3 characters."]);
        exit;
    }

    if ($phone !== "" && strlen($phone) < 8) {
        echo json_encode(["ok"=>false, "msg"=>"Phone number looks too short."]);
        exit;
    }

    $ok = user_updateProfile($userId, $fullName, $phone);

    if ($ok) {
        $_SESSION["user"]["full_name"] = $fullName;
        echo json_encode(["ok"=>true, "msg"=>"Profile updated successfully."]);
        exit;
    }

    echo json_encode(["ok"=>false, "msg"=>"Profile update failed. Try again."]);
    exit;
}

if ($action === "change_password") {
    $current = $_POST["current_password"] ?? "";
    $newPass = $_POST["new_password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";

    if ($current === "" || $newPass === "" || $confirm === "") {
        $_SESSION["flash_error"] = "All password fields are required.";
        header("Location: ../View/change_password.php");
        exit;
    }

    if (strlen($newPass) < 6) {
        $_SESSION["flash_error"] = "New password must be at least 6 characters.";
        header("Location: ../View/change_password.php");
        exit;
    }

    if ($newPass !== $confirm) {
        $_SESSION["flash_error"] = "New password and confirm password do not match.";
        header("Location: ../View/change_password.php");
        exit;
    }

    $hash = user_getPasswordHashById($userId);
    if (!$hash || !password_verify($current, $hash)) {
        $_SESSION["flash_error"] = "Current password is incorrect.";
        header("Location: ../View/change_password.php");
        exit;
    }

    $ok = user_changePassword($userId, $newPass);

    if ($ok) {
        $_SESSION["flash_success"] = "Password changed successfully. Please login again.";
        session_destroy();
        header("Location: ../View/login.php");
        exit;
    }

    $_SESSION["flash_error"] = "Password change failed. Try again.";
    header("Location: ../View/change_password.php");
    exit;
}

header("Location: ../View/dashboard.php");
exit;
