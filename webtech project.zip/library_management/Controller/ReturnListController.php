<?php
session_start();
require_once __DIR__ . "/../Model/Issue.php";

if (!isset($_SESSION["user"])) {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode(["ok"=>false]);
    exit;
}
$role = $_SESSION["user"]["role"] ?? "";
if (!in_array($role, ["admin","librarian"], true)) {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode(["ok"=>false]);
    exit;
}

header("Content-Type: application/json; charset=utf-8");
$keyword = trim($_GET["keyword"] ?? "");
$rows = issue_getIssuedListForReturn($keyword);

echo json_encode(["ok"=>true, "rows"=>$rows]);
exit;
