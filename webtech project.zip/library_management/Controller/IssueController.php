<?php
session_start();
require_once __DIR__ . "/../Model/Issue.php";
require_once __DIR__ . "/../Model/Setting.php";

function mustBeLibrarianOrAdmin(): void {
    if (!isset($_SESSION["user"])) {
        header("Location: ../View/login.php");
        exit;
    }
    $role = $_SESSION["user"]["role"] ?? "";
    if (!in_array($role, ["admin", "librarian"], true)) {
        header("Location: ../View/dashboard.php");
        exit;
    }
}

$action = $_GET["action"] ?? "";


if ($action === "member_issued") {
    header("Content-Type: application/json; charset=utf-8");

    if (!isset($_SESSION["user"]) || ($_SESSION["user"]["role"] ?? "") !== "member") {
        http_response_code(403);
        echo json_encode([]);
        exit;
    }

    $memberId = (int)$_SESSION["user"]["id"];
    $rows = issue_getIssuedByMember($memberId);
    foreach ($rows as &$r) {
        $r['status'] = strtolower($r['status']);
    }
    echo json_encode($rows);
    exit;
}


mustBeLibrarianOrAdmin();


if ($action === "issue") {
    header("Content-Type: application/json; charset=utf-8");

    $requestId = (int)($_POST["request_id"] ?? 0);
    if ($requestId <= 0) {
        echo json_encode(["ok"=>false, "msg"=>"Invalid request"]);
        exit;
    }

    $issuedBy = (int)$_SESSION["user"]["id"];
    $maxDays = (int)setting_get("max_borrow_days", "7");
    if ($maxDays <= 0) $maxDays = 7;

    $result = issue_issueFromRequest($requestId, $issuedBy, $maxDays);
    echo json_encode($result);
    exit;
}
if ($action === "return") {
    header("Content-Type: application/json; charset=utf-8");

    require_once __DIR__ . "/../Model/Setting.php";
    $issueId = (int)($_POST["issue_id"] ?? 0);

    if ($issueId <= 0) {
        echo json_encode(["ok"=>false, "msg"=>"Invalid issue"]);
        exit;
    }

    $finePerDay = (float)setting_get("fine_per_day", "5");
    if ($finePerDay < 0) $finePerDay = 0;

    $result = issue_returnBook($issueId, $finePerDay);
    echo json_encode($result);
    exit;
}


header("Location: ../View/issue_book.php");
exit;
