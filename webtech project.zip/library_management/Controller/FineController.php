<?php
session_start();
require_once __DIR__ . "/../Model/Fine.php";

if (!isset($_SESSION["user"])) {
    header("Location: ../View/login.php");
    exit;
}
$role = $_SESSION["user"]["role"] ?? "";
if (!in_array($role, ["admin","librarian"], true)) {
    header("Location: ../View/dashboard.php");
    exit;
}

$action = $_GET["action"] ?? "";

if ($action === "pay") {
    header("Content-Type: application/json; charset=utf-8");
    $fineId = (int)($_POST["fine_id"] ?? 0);
    $ok = ($fineId > 0) ? fine_markPaid($fineId) : false;
    echo json_encode(["ok"=>$ok]);
    exit;
}

header("Location: ../View/fines.php");
exit;
