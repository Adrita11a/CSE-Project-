<?php
session_start();
require_once __DIR__ . "/../Model/BorrowRequest.php";

if (!isset($_SESSION["user"])) {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode(["ok"=>false,"msg"=>"Not logged in"]);
    exit;
}

$action = $_GET["action"] ?? "";


if ($action === "send") {
    header("Content-Type: application/json; charset=utf-8");

    $role = $_SESSION["user"]["role"] ?? "";
    if ($role !== "member") {
        echo json_encode(["ok"=>false,"msg"=>"Only members can request books"]);
        exit;
    }

    $bookId = (int)($_POST["book_id"] ?? 0);
    $memberId = (int)$_SESSION["user"]["id"];

    if ($bookId <= 0) {
        echo json_encode(["ok"=>false,"msg"=>"Invalid book id"]);
        exit;
    }

    $result = borrowRequest_create($memberId, $bookId);
    echo json_encode($result);
    exit;
}


if ($action === "update") {
    header("Content-Type: application/json; charset=utf-8");

    $role = $_SESSION["user"]["role"] ?? "";
    if (!in_array($role, ["librarian","admin"], true)) {
        echo json_encode(["ok"=>false,"msg"=>"Unauthorized"]);
        exit;
    }

    $id = (int)($_POST["id"] ?? 0);
    $status = $_POST["status"] ?? "";
    $librarianId = (int)$_SESSION["user"]["id"];

    $ok = borrowRequest_updateStatus($id, $status, $librarianId);
    echo json_encode(["ok"=>$ok, "msg"=>$ok ? "Updated" : "Failed"]);
    exit;
}

header("Content-Type: application/json; charset=utf-8");
echo json_encode(["ok"=>false,"msg"=>"Invalid action"]);
exit;
