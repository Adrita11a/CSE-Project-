<?php
session_start();
require_once __DIR__ . "/../Model/Book.php";

function clean(string $s): string { return trim($s); }

function mustBeLibrarianOrAdmin(): void {
    if (!isset($_SESSION["user"])) {
        header("Location: ../View/login.php");
        exit;
    }
    $role = $_SESSION["user"]["role"] ?? "";
    if (!in_array($role, ["admin", "librarian"], true)) {
        header("Location: ../View/dashboard.php");
        exit;
    }
}
mustBeLibrarianOrAdmin();

$action = $_GET["action"] ?? "";


if ($action === "list") {
    header("Content-Type: application/json; charset=utf-8");
    $keyword = clean($_GET["keyword"] ?? "");
    $books = book_getAll($keyword);
    echo json_encode(["ok" => true, "books" => $books]);
    exit;
}


if ($action === "delete") {
    header("Content-Type: application/json; charset=utf-8");
    $id = (int)($_POST["id"] ?? 0);
    $ok = ($id > 0) ? book_delete($id) : false;
    echo json_encode(["ok" => $ok]);
    exit;
}

if ($action === "add" && $_SERVER["REQUEST_METHOD"] === "POST") {
    $data = [
        "isbn" => clean($_POST["isbn"] ?? ""),
        "title" => clean($_POST["title"] ?? ""),
        "author" => clean($_POST["author"] ?? ""),
        "category" => clean($_POST["category"] ?? ""),
        "publisher" => clean($_POST["publisher"] ?? ""),
        "published_year" => (int)($_POST["published_year"] ?? 0),
        "total_copies" => (int)($_POST["total_copies"] ?? 0),
        "available_copies" => (int)($_POST["available_copies"] ?? 0),
        "shelf_location" => clean($_POST["shelf_location"] ?? ""),
        "status" => clean($_POST["status"] ?? "active")
    ];

    
    if ($data["title"] === "" || strlen($data["title"]) < 2) {
        $_SESSION["flash_error"] = "Title is required.";
        header("Location: ../View/librarian_book_add.php");
        exit;
    }
    if ($data["author"] === "" || strlen($data["author"]) < 2) {
        $_SESSION["flash_error"] = "Author is required.";
        header("Location: ../View/librarian_book_add.php");
        exit;
    }
    if ($data["total_copies"] <= 0) {
        $_SESSION["flash_error"] = "Total copies must be greater than 0.";
        header("Location: ../View/librarian_book_add.php");
        exit;
    }
    
    if ($data["available_copies"] < 0 || $data["available_copies"] > $data["total_copies"]) {
        $_SESSION["flash_error"] = "Available copies must be between 0 and Total copies.";
        header("Location: ../View/librarian_book_add.php");
        exit;
    }
    if (!in_array($data["status"], ["active","inactive"], true)) {
        $data["status"] = "active";
    }
    if ($data["published_year"] < 0) $data["published_year"] = 0;

    $ok = book_create($data);
    if ($ok) {
        $_SESSION["flash_success"] = "Book added successfully.";
        header("Location: ../View/librarian_books.php");
        exit;
    }

    $_SESSION["flash_error"] = "Failed to add book.";
    header("Location: ../View/librarian_book_add.php");
    exit;
}


if ($action === "update" && $_SERVER["REQUEST_METHOD"] === "POST") {
    $id = (int)($_POST["id"] ?? 0);

    $data = [
        "isbn" => clean($_POST["isbn"] ?? ""),
        "title" => clean($_POST["title"] ?? ""),
        "author" => clean($_POST["author"] ?? ""),
        "category" => clean($_POST["category"] ?? ""),
        "publisher" => clean($_POST["publisher"] ?? ""),
        "published_year" => (int)($_POST["published_year"] ?? 0),
        "total_copies" => (int)($_POST["total_copies"] ?? 0),
        "available_copies" => (int)($_POST["available_copies"] ?? 0),
        "shelf_location" => clean($_POST["shelf_location"] ?? ""),
        "status" => clean($_POST["status"] ?? "active")
    ];

    if ($id <= 0) {
        $_SESSION["flash_error"] = "Invalid book.";
        header("Location: ../View/librarian_books.php");
        exit;
    }

    if ($data["title"] === "" || strlen($data["title"]) < 2) {
        $_SESSION["flash_error"] = "Title is required.";
        header("Location: ../View/librarian_book_edit.php?id=" . $id);
        exit;
    }
    if ($data["author"] === "" || strlen($data["author"]) < 2) {
        $_SESSION["flash_error"] = "Author is required.";
        header("Location: ../View/librarian_book_edit.php?id=" . $id);
        exit;
    }
    if ($data["total_copies"] <= 0) {
        $_SESSION["flash_error"] = "Total copies must be greater than 0.";
        header("Location: ../View/librarian_book_edit.php?id=" . $id);
        exit;
    }
    if ($data["available_copies"] < 0 || $data["available_copies"] > $data["total_copies"]) {
        $_SESSION["flash_error"] = "Available copies must be between 0 and Total copies.";
        header("Location: ../View/librarian_book_edit.php?id=" . $id);
        exit;
    }
    if (!in_array($data["status"], ["active","inactive"], true)) {
        $data["status"] = "active";
    }

    $ok = book_update($id, $data);
    if ($ok) {
        $_SESSION["flash_success"] = "Book updated successfully.";
        header("Location: ../View/librarian_books.php");
        exit;
    }

    $_SESSION["flash_error"] = "Failed to update book.";
    header("Location: ../View/librarian_book_edit.php?id=" . $id);
    exit;
}

header("Location: ../View/librarian_books.php");
exit;
