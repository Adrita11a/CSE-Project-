<?php
session_start();
require_once __DIR__ . "/../Model/Admin.php";

function clean(string $s): string { return trim($s); }

function mustBeAdmin(): void {
    if (!isset($_SESSION["user"])) {
        header("Location: ../View/login.php");
        exit;
    }
    if (($_SESSION["user"]["role"] ?? "") !== "admin") {
        header("Location: ../View/dashboard.php");
        exit;
    }
}

mustBeAdmin();

$action = $_GET["action"] ?? "";


if ($action === "list") {
    header("Content-Type: application/json; charset=utf-8");

    $keyword = clean($_GET["keyword"] ?? "");
    $role    = clean($_GET["role"] ?? "");

    $users = admin_getUsers($keyword, $role);
    echo json_encode(["ok" => true, "users" => $users]);
    exit;
}


if ($action === "status") {
    header("Content-Type: application/json; charset=utf-8");

    $userId = (int)($_POST["user_id"] ?? 0);
    $status = clean($_POST["status"] ?? "");

    
    $myId = (int)$_SESSION["user"]["id"];
    if ($userId === $myId) {
        echo json_encode(["ok" => false, "msg" => "You cannot change your own status."]);
        exit;
    }

    $ok = admin_setUserStatus($userId, $status);
    echo json_encode(["ok" => $ok, "msg" => $ok ? "Updated" : "Failed"]);
    exit;
}


if ($action === "add" && $_SERVER["REQUEST_METHOD"] === "POST") {
    $fullName = clean($_POST["full_name"] ?? "");
    $email    = clean($_POST["email"] ?? "");
    $phone    = clean($_POST["phone"] ?? "");
    $role     = clean($_POST["role"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm  = $_POST["confirm_password"] ?? "";

    
    if ($fullName === "" || strlen($fullName) < 3) {
        $_SESSION["flash_error"] = "Full name must be at least 3 characters.";
        header("Location: ../View/admin_user_add.php");
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION["flash_error"] = "Invalid email format.";
        header("Location: ../View/admin_user_add.php");
        exit;
    }

    if (!in_array($role, ["librarian", "member"], true)) {
        $_SESSION["flash_error"] = "Role must be Librarian or Member.";
        header("Location: ../View/admin_user_add.php");
        exit;
    }

    if (strlen($password) < 6) {
        $_SESSION["flash_error"] = "Password must be at least 6 characters.";
        header("Location: ../View/admin_user_add.php");
        exit;
    }

    if ($password !== $confirm) {
        $_SESSION["flash_error"] = "Passwords do not match.";
        header("Location: ../View/admin_user_add.php");
        exit;
    }

    if (admin_emailExists($email)) {
        $_SESSION["flash_error"] = "Email already exists.";
        header("Location: ../View/admin_user_add.php");
        exit;
    }

    $ok = admin_createUser($fullName, $email, $phone, $password, $role);

    if ($ok) {
        $_SESSION["flash_success"] = "User created successfully.";
        header("Location: ../View/admin_users.php");
        exit;
    }

    $_SESSION["flash_error"] = "Failed to create user.";
    header("Location: ../View/admin_user_add.php");
    exit;
}

header("Location: ../View/admin_users.php");
exit;
