<?php
session_start();
require_once __DIR__ . "/../Model/Book.php";

if (!isset($_SESSION["user"])) {
    header("Location: ../View/login.php");
    exit;
}

header("Content-Type: application/json; charset=utf-8");

$keyword = trim($_GET["keyword"] ?? "");
$books = book_getAll($keyword);

echo json_encode(["ok" => true, "books" => $books]);
exit;
