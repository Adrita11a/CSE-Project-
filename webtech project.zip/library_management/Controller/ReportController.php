<?php
session_start();
require_once __DIR__ . "/../Model/Report.php";

if (!isset($_SESSION["user"])) {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode(["ok"=>false]);
    exit;
}
if (($_SESSION["user"]["role"] ?? "") !== "admin") {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode(["ok"=>false]);
    exit;
}

header("Content-Type: application/json; charset=utf-8");
echo json_encode(["ok"=>true, "counts"=>report_dashboardCounts()]);
exit;
