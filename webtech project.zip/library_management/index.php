<?php
session_start();

if (isset($_SESSION['user'])) {
    header("Location: View/dashboard.php");
    exit;
}
header("Location: View/login.php");
exit;
